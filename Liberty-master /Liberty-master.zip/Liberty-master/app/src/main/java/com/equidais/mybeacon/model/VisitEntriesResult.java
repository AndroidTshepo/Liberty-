package com.equidais.mybeacon.model;

public class VisitEntriesResult {
    public String TimeIn;
    public String TimeOut;
    public String Gym;

    public VisitEntriesResult(){
        TimeIn = null;
        TimeOut = null;
        Gym = "";
    }
}
