package com.equidais.mybeacon.controller.common;

import android.support.v4.app.Fragment;
import android.view.View;


public class BaseFragment extends Fragment {

    public View mRootView;


}
