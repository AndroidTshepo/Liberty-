package com.equidais.mybeacon.controller.common;


public class Constant {
    public static final String BLE_STATE_CHANGED_ACTION = "android.bluetooth.adapter.action.STATE_CHANGED";
    public static final String BASE_URL = "http://masscash.empirestate.co.za/gravity";
}
