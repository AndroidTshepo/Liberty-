package com.equidais.mybeacon.common;


public class GlobalConst {
    public static final String API_ROOT = "http://masscash.empirestate.co.za/GenyaApi/X";


    public static final String PREF_NAME = "mybeacon";

    public static final String PREF_ATTR_USERNAME = "username";
    public static final String PREF_ATTR_PASSWORD = "password";
    public static final String PREF_ATTR_USERID = "userid";
    public static final String PREF_ATTR_PUSH_STATE = "push_state";
    public static final String PREF_ATTR_PUSH_REGID = "push_regid";

    public static final String GCM_SENDER_ID = "363675486073"; //AIzaSyCn81a0fovM8wS7ykuB2jujRjnPfGoyRTA

}
