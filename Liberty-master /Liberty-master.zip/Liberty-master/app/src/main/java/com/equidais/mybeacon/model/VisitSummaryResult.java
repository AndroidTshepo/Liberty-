package com.equidais.mybeacon.model;

public class VisitSummaryResult {
    public Long VisitCount;
    public String AvgVisitDuration;
    public String LastVisitDate;

    public VisitSummaryResult(){
        VisitCount = null;
        AvgVisitDuration = null;
        LastVisitDate = "";
    }
}
