package com.equidais.mybeacon.controller.main;

import android.support.v7.app.AppCompatActivity;

import com.equidais.mybeacon.controller.MainApplication;

/**
 * Created by empirestate on 4/20/16.
 */
public class GetDuration extends AppCompatActivity {



}
