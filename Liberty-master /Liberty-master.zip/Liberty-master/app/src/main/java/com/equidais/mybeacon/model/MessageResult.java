package com.equidais.mybeacon.model;

import android.app.TimePickerDialog;

/**
 * Created by daydreamer on 8/12/2015.
 */
public class MessageResult {
    public String Title;
    public String Message;
    public String Gym;

    public MessageResult(){
        Title = "";
        Message = "";
        Gym = "";
    }
}
